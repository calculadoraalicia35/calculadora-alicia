# Calculadora Alicia – Calculadoras Matemáticas Paso a Paso

Plugins de WordPress y recursos abiertos para enseñar matemáticas mostrando **el procedimiento completo**, no solo el resultado.

Este repositorio contiene el código de las calculadoras que usamos en [Calculadora Alicia](https://calculadoraaliciaai.es/), una herramienta gratuita para estudiantes de primaria y secundaria, padres y profesores.

**Demos en vivo:**
- [Calculadora de operaciones combinadas](https://USUARIO.github.io/calculadora-alicia/operaciones-combinadas.html)
- [Calculadora de regla de tres](https://USUARIO.github.io/calculadora-alicia/regla-de-tres.html)

---

## Por qué existe este proyecto

Cuando un estudiante obtiene un resultado equivocado, una calculadora normal no le dice **en qué paso** se equivocó. Solo muestra un número. Estas herramientas resuelven el ejercicio mostrando cada paso intermedio y la regla aplicada en cada uno, para que el error se pueda localizar y entender.

---

## Contenido

### 1. Operaciones Combinadas (`plugins/alicia-operaciones-combinadas`)

Calculadora de operaciones combinadas con tres modos: calculadora paso a paso, ejercicios de práctica y tabla de reglas.

- Aplica la jerarquía de operaciones y **nombra la regla usada en cada paso**
- Paréntesis `( )`, corchetes `[ ]` y llaves `{ }` anidados
- Potencias, raíces cuadradas, números negativos y ley de signos
- **Aritmética exacta con fracciones**: `1/2 + 3/4 × 2/3 = 1`, no `0,9999`
- Casos que muchas calculadoras resuelven mal: `−3² = −9` pero `(−3)² = 9`, y `12 ÷ 3 × 2 = 8`
- Generador de ejercicios de práctica para primaria y secundaria

Shortcode: `[alicia_operaciones_combinadas]`

### 2. Regla de Tres (`plugins/alicia-regla-de-tres`)

Calculadora de regla de tres con tres modos.

- **Simple**: proporción directa e inversa, con verificación automática del resultado
- **Compuesta**: de dos a cuatro magnitudes, cada una directa o inversa (también mixtas)
- **Porcentajes**: porcentaje de un número, qué porcentaje representa una parte, y hallar el total
- Formato de números en español: acepta `1.234,56` y `1234.56`, devuelve `19,2` y `1.440`

Shortcode: `[alicia_regla_de_tres]`

### 3. Recursos (`docs/`)

- Demos HTML independientes de ambas calculadoras (no necesitan WordPress)
- Infografía de la jerarquía de operaciones

---

## Instalación en WordPress

1. Descarga la carpeta del plugin y comprímela en un `.zip`
2. En WordPress: **Plugins → Añadir nuevo → Subir plugin → Activar**
3. Inserta el shortcode correspondiente en cualquier página o entrada

## Uso sin WordPress

Los archivos de `docs/` son páginas HTML independientes: ábrelas en el navegador o súbelas a cualquier hosting. También puedes copiar el CSS y el JS de `plugins/*/assets/` en tu propio proyecto.

---

## Detalles técnicos

- JavaScript sin dependencias (no usa jQuery ni ningún framework)
- CSS con todas las reglas limitadas a la clase raíz del widget, para que no afecte al tema
- Los assets solo se cargan en las páginas que usan el shortcode
- Varias instancias del widget pueden convivir en la misma página
- Marcado accesible con roles ARIA y navegación por teclado
- Schema.org `WebApplication` incluido

### Cómo funciona el motor de operaciones combinadas

1. Tokeniza la expresión y normaliza el signo menos unario y la multiplicación implícita
2. Localiza el grupo más interno y lo resuelve primero
3. Dentro de cada grupo aplica el orden: raíces → potencias (derecha a izquierda) → signo negativo → multiplicación y división (izquierda a derecha) → suma y resta (izquierda a derecha)
4. Reescribe la expresión completa después de cada operación, de forma que cada paso es legible por sí solo
5. Los valores se manejan como fracciones exactas siempre que es posible

---

## Recursos de matemáticas

Guías gratuitas relacionadas con estas calculadoras:

- [Jerarquía de operaciones paso a paso](https://calculadoraaliciaai.es/jerarquia-de-operaciones/)
- [Fracciones: guía completa](https://calculadoraaliciaai.es/fracciones/)
- [División larga: el método de cuatro pasos](https://calculadoraaliciaai.es/division-larga/)
- [Números primos y factorización](https://calculadoraaliciaai.es/numeros-primos/)
- [Todas las calculadoras](https://calculadoraaliciaai.es/)

---

## Contribuir

Los issues y pull requests son bienvenidos, sobre todo si encuentras un caso matemático que se resuelve mal. Incluye la expresión exacta y el resultado esperado.

## Licencia

GPL-2.0-or-later. Consulta el archivo [LICENSE](LICENSE).
