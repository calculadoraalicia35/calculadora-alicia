# Cómo contribuir

Gracias por tu interés en mejorar estas calculadoras.

## Reportar un error de cálculo

Es el tipo de issue más útil. Incluye:

1. La expresión o los valores exactos que introdujiste
2. El resultado que devolvió la calculadora
3. El resultado correcto y, si puedes, el procedimiento

## Pull requests

- Mantén el JavaScript sin dependencias externas
- Conserva el prefijo de clase CSS de cada widget (`aoc-`, `art-`) para no afectar al tema de WordPress
- Añade el caso de prueba correspondiente en la descripción del PR

## Traducciones

Los textos de la interfaz están en español. Si quieres añadir otro idioma, abre un issue antes de empezar.
