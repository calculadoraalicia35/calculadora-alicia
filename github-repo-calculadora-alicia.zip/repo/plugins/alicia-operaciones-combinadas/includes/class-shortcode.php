<?php
/**
 * Shortcode handler — renders [alicia_operaciones_combinadas].
 *
 * @package AliciaOperacionesCombinadas
 */

namespace AliciaOperacionesCombinadas;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Shortcode {

	const TAG = 'alicia_operaciones_combinadas';

	private $assets;
	private $schema_printed = false;

	public function __construct( Assets $assets ) {
		$this->assets = $assets;
	}

	public function register() {
		add_shortcode( self::TAG, array( $this, 'render' ) );
	}

	public function render( $atts ) {
		$atts = shortcode_atts(
			array( 'subtitle' => __( 'Operaciones Combinadas · Paso a paso', 'alicia-operaciones-combinadas' ) ),
			$atts,
			self::TAG
		);
		$this->assets->flag_load();
		$id = 'aoc-' . wp_unique_id();
		ob_start();
		$this->print_schema();
		$this->print_markup( $atts, $id );
		return ob_get_clean();
	}

	private function print_schema() {
		if ( $this->schema_printed ) {
			return;
		}
		$this->schema_printed = true;
		$schema = array(
			'@context'            => 'https://schema.org',
			'@type'               => 'WebApplication',
			'name'                => 'Calculadora Alicia AI – Operaciones Combinadas',
			'applicationCategory' => 'EducationalApplication',
			'operatingSystem'     => 'Web',
			'url'                 => 'https://calculadoraaliciaai.es',
			'inLanguage'          => 'es-ES',
			'offers'              => array(
				'@type'         => 'Offer',
				'price'         => '0',
				'priceCurrency' => 'EUR',
			),
			'featureList'         => array(
				'Resolución de operaciones combinadas paso a paso',
				'Jerarquía de operaciones aplicada en cada paso',
				'Paréntesis, corchetes y llaves anidados',
				'Potencias y raíces cuadradas',
				'Números negativos y ley de signos',
				'Resultados exactos con fracciones',
				'Ejercicios de práctica de primaria y secundaria',
			),
		);
		echo '<script type="application/ld+json">' . wp_json_encode( $schema ) . '</script>';
	}

	private function print_markup( $atts, $id ) {
		?>
		<div id="<?php echo esc_attr( $id ); ?>" class="aoc-root" role="region" aria-label="<?php esc_attr_e( 'Calculadora de Operaciones Combinadas', 'alicia-operaciones-combinadas' ); ?>">

			<div class="aoc-header">
				<svg class="aoc-logo" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
					<path d="M8 94 L41 18 Q50 4 59 18 L92 94 Z M50 46 L32 94 L68 94 Z" fill="#FFFFFF" fill-rule="evenodd"/>
					<path d="M50 49 Q50 62 63 62 Q50 62 50 75 Q50 62 37 62 Q50 62 50 49 Z" fill="#F7AD00"/>
				</svg>
				<div class="aoc-brand">
					<div class="aoc-brand-name">Calculadora Alicia <span class="ai">AI</span></div>
					<div class="aoc-brand-sub"><?php echo esc_html( $atts['subtitle'] ); ?></div>
				</div>
				<span class="aoc-badge"><?php esc_html_e( 'GRATIS', 'alicia-operaciones-combinadas' ); ?></span>
			</div>

			<div class="aoc-body">

				<div class="aoc-mode-tabs" role="tablist">
					<button type="button" class="aoc-tab active" data-mode="calc" role="tab" aria-selected="true">
						<span class="aoc-ico" data-i="calc"></span><?php esc_html_e( 'Calculadora', 'alicia-operaciones-combinadas' ); ?>
					</button>
					<button type="button" class="aoc-tab" data-mode="practica" role="tab" aria-selected="false">
						<span class="aoc-ico" data-i="practice"></span><?php esc_html_e( 'Practicar', 'alicia-operaciones-combinadas' ); ?>
					</button>
					<button type="button" class="aoc-tab" data-mode="reglas" role="tab" aria-selected="false">
						<span class="aoc-ico" data-i="rules"></span><?php esc_html_e( 'Reglas', 'alicia-operaciones-combinadas' ); ?>
					</button>
				</div>

				<div class="aoc-shell" data-role="body"></div>

			</div>
		</div>
		<?php
	}
}
