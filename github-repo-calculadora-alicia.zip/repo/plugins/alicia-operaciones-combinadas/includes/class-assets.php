<?php
/**
 * Asset registration and conditional enqueueing.
 *
 * @package AliciaOperacionesCombinadas
 */

namespace AliciaOperacionesCombinadas;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Assets {

	const HANDLE = 'alicia-operaciones-combinadas';

	private $should_load = false;

	public function register() {
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'maybe_enqueue' ), 20 );
	}

	public function register_assets() {
		wp_register_style(
			self::HANDLE . '-fonts',
			'https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&display=swap',
			array(),
			ALICIA_OC_VERSION
		);
		wp_register_style(
			self::HANDLE,
			ALICIA_OC_URL . 'assets/css/alicia-operaciones-combinadas.css',
			array( self::HANDLE . '-fonts' ),
			ALICIA_OC_VERSION
		);
		wp_register_script(
			self::HANDLE,
			ALICIA_OC_URL . 'assets/js/alicia-operaciones-combinadas.js',
			array(),
			ALICIA_OC_VERSION,
			true
		);
	}

	public function flag_load() {
		$this->should_load = true;
		if ( did_action( 'wp_enqueue_scripts' ) ) {
			$this->enqueue();
		}
	}

	public function maybe_enqueue() {
		if ( $this->should_load ) {
			$this->enqueue();
		}
	}

	private function enqueue() {
		wp_enqueue_style( self::HANDLE . '-fonts' );
		wp_enqueue_style( self::HANDLE );
		wp_enqueue_script( self::HANDLE );
	}
}
