<?php
/**
 * Plugin Name:       Calculadora Alicia AI – Operaciones Combinadas
 * Plugin URI:        https://calculadoraaliciaai.es
 * Description:       Calculadora de operaciones combinadas con solución paso a paso, jerarquía de operaciones, paréntesis, corchetes, llaves, potencias, raíces, negativos y fracciones exactas. Renders via [alicia_operaciones_combinadas]. Vanilla JS, no jQuery, scoped CSS.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Calculadora Alicia AI
 * Author URI:        https://calculadoraaliciaai.es
 * License:           GPL-2.0-or-later
 * Text Domain:       alicia-operaciones-combinadas
 *
 * @package AliciaOperacionesCombinadas
 */

namespace AliciaOperacionesCombinadas;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'ALICIA_OC_VERSION', '1.0.0' );
define( 'ALICIA_OC_FILE', __FILE__ );
define( 'ALICIA_OC_PATH', plugin_dir_path( __FILE__ ) );
define( 'ALICIA_OC_URL', plugin_dir_url( __FILE__ ) );
define( 'ALICIA_OC_BASENAME', plugin_basename( __FILE__ ) );

spl_autoload_register(
	static function ( $class ) {
		$prefix = __NAMESPACE__ . '\\';
		if ( 0 !== strpos( $class, $prefix ) ) {
			return;
		}
		$relative  = substr( $class, strlen( $prefix ) );
		$file_slug = strtolower( str_replace( '_', '-', $relative ) );
		$path      = ALICIA_OC_PATH . 'includes/class-' . $file_slug . '.php';
		if ( is_readable( $path ) ) {
			require_once $path;
		}
	}
);

function alicia_oc_bootstrap() {
	Plugin::instance();
}
add_action( 'plugins_loaded', __NAMESPACE__ . '\\alicia_oc_bootstrap' );
