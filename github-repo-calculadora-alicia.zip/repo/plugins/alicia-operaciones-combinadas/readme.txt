=== Calculadora Alicia AI – Operaciones Combinadas ===
Contributors: calculadoraaliciaai
Tags: operaciones combinadas, jerarquia de operaciones, calculadora, math, educacion
Requires at least: 5.8
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

Calculadora de operaciones combinadas con solución paso a paso, jerarquía de operaciones, ejercicios de práctica y tabla de reglas.

== Description ==

Three tools in one widget, all in Spanish:

* **Calculadora** — solves any combined operation and shows every step, naming the rule applied (grouping symbols, powers and roots, multiplication/division left to right, addition/subtraction left to right)
* **Practicar** — random exercises for primaria and secundaria, with answer checking and full solution
* **Reglas** — order of operations table, sign rules table and the most common mistakes

Supported input: + - × ÷ ^ √ %, parentheses ( ), brackets [ ], braces { }, negative numbers, decimals with comma or point, and exact fraction results (1/2 + 3/4 × 2/3 = 1).

Use: `[alicia_operaciones_combinadas]`

Optional subtitle: `[alicia_operaciones_combinadas subtitle="Jerarquía de operaciones"]`

== Installation ==

1. Upload ZIP via Plugins → Add New → Upload Plugin → Activate
2. Add `[alicia_operaciones_combinadas]` to any page or post

== Changelog ==

= 1.0.0 =
* Initial release.
