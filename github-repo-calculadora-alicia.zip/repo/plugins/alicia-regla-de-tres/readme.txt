=== Calculadora Alicia AI – Regla de Tres ===
Contributors: calculadoraaliciaai
Tags: regla de tres, proporciones, porcentajes, calculadora, educacion
Requires at least: 5.8
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

Calculadora de regla de tres simple (directa e inversa), compuesta y de porcentajes, con solución paso a paso.

== Description ==

Three modes in one widget, all in Spanish:

* **Simple** — direct and inverse proportion. Enter A, B and C, get X with every step and an automatic verification (A/B = C/X for direct, A×B = C×X for inverse). Optional unit label. Three worked examples included.
* **Compuesta** — two to four magnitudes at once, each marked direct or inverse (mixed supported). Shows the ratio used for each magnitude and the partial result after each one.
* **Porcentajes** — three calculations: X% of a number, what percentage a part represents, and finding the total from a known percentage. Each solved as a rule of three.

Spanish number handling: accepts 1.234,56 and 1234.56 as input, outputs Spanish format (19,2 · 1.440).

Use: `[alicia_regla_de_tres]`

Optional subtitle: `[alicia_regla_de_tres subtitle="Simple, compuesta y porcentajes"]`

== Installation ==

1. Upload ZIP via Plugins → Add New → Upload Plugin → Activate
2. Add `[alicia_regla_de_tres]` to any page or post

== Changelog ==

= 1.0.0 =
* Initial release.
