<?php
/**
 * Plugin Name:       Calculadora Alicia AI – Regla de Tres
 * Plugin URI:        https://calculadoraaliciaai.es
 * Description:       Calculadora de regla de tres simple (directa e inversa), compuesta y de porcentajes, con solución paso a paso y verificación. Renders via [alicia_regla_de_tres]. Vanilla JS, no jQuery, scoped CSS.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Calculadora Alicia AI
 * Author URI:        https://calculadoraaliciaai.es
 * License:           GPL-2.0-or-later
 * Text Domain:       alicia-regla-de-tres
 *
 * @package AliciaReglaDeTres
 */

namespace AliciaReglaDeTres;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'ALICIA_RT_VERSION', '1.0.0' );
define( 'ALICIA_RT_FILE', __FILE__ );
define( 'ALICIA_RT_PATH', plugin_dir_path( __FILE__ ) );
define( 'ALICIA_RT_URL', plugin_dir_url( __FILE__ ) );
define( 'ALICIA_RT_BASENAME', plugin_basename( __FILE__ ) );

spl_autoload_register(
	static function ( $class ) {
		$prefix = __NAMESPACE__ . '\\';
		if ( 0 !== strpos( $class, $prefix ) ) {
			return;
		}
		$relative  = substr( $class, strlen( $prefix ) );
		$file_slug = strtolower( str_replace( '_', '-', $relative ) );
		$path      = ALICIA_RT_PATH . 'includes/class-' . $file_slug . '.php';
		if ( is_readable( $path ) ) {
			require_once $path;
		}
	}
);

function alicia_rt_bootstrap() {
	Plugin::instance();
}
add_action( 'plugins_loaded', __NAMESPACE__ . '\\alicia_rt_bootstrap' );
