<?php
/**
 * Plugin orchestrator.
 *
 * @package AliciaReglaDeTres
 */

namespace AliciaReglaDeTres;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Plugin {

	private static $instance = null;
	private $assets;
	private $shortcode;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$this->assets    = new Assets();
		$this->shortcode = new Shortcode( $this->assets );
		$this->assets->register();
		$this->shortcode->register();
		add_action( 'init', static function () {
			load_plugin_textdomain( 'alicia-regla-de-tres', false, dirname( ALICIA_RT_BASENAME ) . '/languages' );
		} );
	}

	private function __clone() {}
	public function __wakeup() {}
}
