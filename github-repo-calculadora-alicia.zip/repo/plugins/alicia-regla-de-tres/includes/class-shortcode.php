<?php
/**
 * Shortcode handler — renders [alicia_regla_de_tres].
 *
 * @package AliciaReglaDeTres
 */

namespace AliciaReglaDeTres;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Shortcode {

	const TAG = 'alicia_regla_de_tres';

	private $assets;
	private $schema_printed = false;

	public function __construct( Assets $assets ) {
		$this->assets = $assets;
	}

	public function register() {
		add_shortcode( self::TAG, array( $this, 'render' ) );
	}

	public function render( $atts ) {
		$atts = shortcode_atts(
			array( 'subtitle' => __( 'Regla de Tres · Paso a paso', 'alicia-regla-de-tres' ) ),
			$atts,
			self::TAG
		);
		$this->assets->flag_load();
		$id = 'art-' . wp_unique_id();
		ob_start();
		$this->print_schema();
		$this->print_markup( $atts, $id );
		return ob_get_clean();
	}

	private function print_schema() {
		if ( $this->schema_printed ) {
			return;
		}
		$this->schema_printed = true;
		$schema = array(
			'@context'            => 'https://schema.org',
			'@type'               => 'WebApplication',
			'name'                => 'Calculadora Alicia AI – Regla de Tres',
			'applicationCategory' => 'EducationalApplication',
			'operatingSystem'     => 'Web',
			'url'                 => 'https://calculadoraaliciaai.es',
			'inLanguage'          => 'es-ES',
			'offers'              => array(
				'@type'         => 'Offer',
				'price'         => '0',
				'priceCurrency' => 'EUR',
			),
			'featureList'         => array(
				'Regla de tres simple directa e inversa paso a paso',
				'Regla de tres compuesta con varias magnitudes',
				'Relaciones directas, inversas y mixtas',
				'Cálculo de porcentajes con regla de tres',
				'Verificación automática del resultado',
			),
		);
		echo '<script type="application/ld+json">' . wp_json_encode( $schema ) . '</script>';
	}

	private function print_markup( $atts, $id ) {
		?>
		<div id="<?php echo esc_attr( $id ); ?>" class="art-root" role="region" aria-label="<?php esc_attr_e( 'Calculadora de Regla de Tres', 'alicia-regla-de-tres' ); ?>">

			<div class="art-header">
				<svg class="art-logo" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
					<path d="M8 94 L41 18 Q50 4 59 18 L92 94 Z M50 46 L32 94 L68 94 Z" fill="#FFFFFF" fill-rule="evenodd"/>
					<path d="M50 49 Q50 62 63 62 Q50 62 50 75 Q50 62 37 62 Q50 62 50 49 Z" fill="#F7AD00"/>
				</svg>
				<div class="art-brand">
					<div class="art-brand-name">Calculadora Alicia <span class="ai">AI</span></div>
					<div class="art-brand-sub"><?php echo esc_html( $atts['subtitle'] ); ?></div>
				</div>
				<span class="art-badge"><?php esc_html_e( 'GRATIS', 'alicia-regla-de-tres' ); ?></span>
			</div>

			<div class="art-body">

				<div class="art-mode-tabs" role="tablist">
					<button type="button" class="art-tab active" data-mode="simple" role="tab" aria-selected="true">
						<span class="art-ico" data-i="simple"></span><?php esc_html_e( 'Simple', 'alicia-regla-de-tres' ); ?>
					</button>
					<button type="button" class="art-tab" data-mode="compuesta" role="tab" aria-selected="false">
						<span class="art-ico" data-i="compuesta"></span><?php esc_html_e( 'Compuesta', 'alicia-regla-de-tres' ); ?>
					</button>
					<button type="button" class="art-tab" data-mode="porcentajes" role="tab" aria-selected="false">
						<span class="art-ico" data-i="pct"></span><?php esc_html_e( 'Porcentajes', 'alicia-regla-de-tres' ); ?>
					</button>
				</div>

				<div class="art-shell" data-role="body"></div>

			</div>
		</div>
		<?php
	}
}
