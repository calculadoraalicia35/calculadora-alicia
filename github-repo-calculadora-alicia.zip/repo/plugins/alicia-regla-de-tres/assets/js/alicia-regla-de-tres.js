/**
 * Calculadora Alicia AI – Regla de Tres
 * Modes: simple | compuesta | porcentajes
 * Vanilla JS. No jQuery. Multi-instance safe.
 */
(function () {
	'use strict';

	/* ============================================================
	 * HELPERS
	 * ========================================================== */

	function parseNum(raw) {
		if (raw === null || raw === undefined) { return NaN; }
		var s = String(raw).trim().replace(/\s/g, '');
		if (!s) { return NaN; }
		/* Spanish input: 1.234,56 or 1234,56 or 1234.56 */
		if (s.indexOf(',') !== -1) {
			s = s.replace(/\./g, '').replace(',', '.');
		}
		var n = parseFloat(s);
		return isFinite(n) ? n : NaN;
	}

	function fmt(n) {
		if (!isFinite(n)) { return '—'; }
		var r = Math.round(n * 1e6) / 1e6;
		var s = String(r);
		var parts = s.split('.');
		var int = parts[0];
		var neg = int[0] === '-';
		if (neg) { int = int.slice(1); }
		int = int.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
		var out = (neg ? '-' : '') + int;
		if (parts[1]) { out += ',' + parts[1]; }
		return out;
	}

	function esc(s) {
		return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
	}

	/* ============================================================
	 * ENGINES
	 * ========================================================== */

	function solveSimple(a, b, c, type) {
		if (!isFinite(a) || !isFinite(b) || !isFinite(c)) {
			throw new Error('Completa los tres valores conocidos con números.');
		}
		if (type === 'directa' && a === 0) { throw new Error('El valor A no puede ser cero en una proporción directa.'); }
		if (type === 'inversa' && c === 0) { throw new Error('El valor C no puede ser cero en una proporción inversa.'); }

		var x, steps = [], check;

		if (type === 'directa') {
			x = (c * b) / a;
			steps = [
				{ r: 'Identifica el tipo', t: 'La relación es directa: si una cantidad aumenta, la otra también aumenta.' },
				{ r: 'Plantea la proporción', t: fmt(a) + ' → ' + fmt(b) + '  y  ' + fmt(c) + ' → X' },
				{ r: 'Aplica la fórmula', t: 'X = (C × B) ÷ A = (' + fmt(c) + ' × ' + fmt(b) + ') ÷ ' + fmt(a) },
				{ r: 'Multiplica', t: fmt(c) + ' × ' + fmt(b) + ' = ' + fmt(c * b) },
				{ r: 'Divide', t: fmt(c * b) + ' ÷ ' + fmt(a) + ' = ' + fmt(x) }
			];
			check = 'A ÷ B debe ser igual a C ÷ X:  ' + fmt(a) + ' ÷ ' + fmt(b) + ' = ' + fmt(a / b) +
				'  y  ' + fmt(c) + ' ÷ ' + fmt(x) + ' = ' + fmt(c / x);
		} else {
			x = (a * b) / c;
			steps = [
				{ r: 'Identifica el tipo', t: 'La relación es inversa: si una cantidad aumenta, la otra disminuye.' },
				{ r: 'Plantea la proporción', t: fmt(a) + ' → ' + fmt(b) + '  y  ' + fmt(c) + ' → X' },
				{ r: 'Aplica la fórmula', t: 'X = (A × B) ÷ C = (' + fmt(a) + ' × ' + fmt(b) + ') ÷ ' + fmt(c) },
				{ r: 'Multiplica', t: fmt(a) + ' × ' + fmt(b) + ' = ' + fmt(a * b) },
				{ r: 'Divide', t: fmt(a * b) + ' ÷ ' + fmt(c) + ' = ' + fmt(x) }
			];
			check = 'A × B debe ser igual a C × X:  ' + fmt(a * b) + ' = ' + fmt(c * x);
		}
		return { x: x, steps: steps, check: check };
	}

	function solveCompuesta(base, rows) {
		if (!isFinite(base)) { throw new Error('Escribe el valor conocido de la magnitud que buscas.'); }
		var used = rows.filter(function (r) { return isFinite(r.from) && isFinite(r.to); });
		if (!used.length) { throw new Error('Completa al menos una magnitud con sus dos valores.'); }

		var x = base, steps = [], factors = [];
		steps.push({ r: 'Punto de partida', t: 'El valor conocido de la magnitud buscada es ' + fmt(base) + '.' });

		used.forEach(function (r, i) {
			var num, den, why;
			if (r.rel === 'directa') {
				if (r.from === 0) { throw new Error('El primer valor de la magnitud ' + (i + 1) + ' no puede ser cero.'); }
				num = r.to; den = r.from;
				why = 'es directa, así que la razón se escribe ' + fmt(r.to) + ' ÷ ' + fmt(r.from) + '.';
			} else {
				if (r.to === 0) { throw new Error('El segundo valor de la magnitud ' + (i + 1) + ' no puede ser cero.'); }
				num = r.from; den = r.to;
				why = 'es inversa, así que la razón se invierte: ' + fmt(r.from) + ' ÷ ' + fmt(r.to) + '.';
			}
			var f = num / den;
			factors.push(fmt(num) + ' ÷ ' + fmt(den));
			x = x * f;
			steps.push({
				r: 'Magnitud ' + (i + 1) + (r.name ? ' · ' + r.name : ''),
				t: 'Pasa de ' + fmt(r.from) + ' a ' + fmt(r.to) + '. La relación ' + why +
					' Resultado parcial: ' + fmt(x) + '.'
			});
		});

		steps.push({
			r: 'Operación completa',
			t: 'X = ' + fmt(base) + ' × (' + factors.join(') × (') + ') = ' + fmt(x)
		});
		return { x: x, steps: steps, check: null };
	}

	function solvePorcentaje(mode, p, n) {
		var x, steps, check = null;
		if (mode === 'deN') {
			if (!isFinite(p) || !isFinite(n)) { throw new Error('Completa el porcentaje y el total.'); }
			x = (p * n) / 100;
			steps = [
				{ r: 'Plantea la regla de tres', t: '100 → ' + fmt(n) + '  y  ' + fmt(p) + ' → X' },
				{ r: 'Aplica la fórmula', t: 'X = (' + fmt(p) + ' × ' + fmt(n) + ') ÷ 100' },
				{ r: 'Multiplica', t: fmt(p) + ' × ' + fmt(n) + ' = ' + fmt(p * n) },
				{ r: 'Divide', t: fmt(p * n) + ' ÷ 100 = ' + fmt(x) }
			];
		} else if (mode === 'queP') {
			if (!isFinite(p) || !isFinite(n)) { throw new Error('Completa los dos valores.'); }
			if (n === 0) { throw new Error('El total no puede ser cero.'); }
			x = (p * 100) / n;
			steps = [
				{ r: 'Plantea la regla de tres', t: fmt(n) + ' → 100  y  ' + fmt(p) + ' → X' },
				{ r: 'Aplica la fórmula', t: 'X = (' + fmt(p) + ' × 100) ÷ ' + fmt(n) },
				{ r: 'Multiplica', t: fmt(p) + ' × 100 = ' + fmt(p * 100) },
				{ r: 'Divide', t: fmt(p * 100) + ' ÷ ' + fmt(n) + ' = ' + fmt(x) + ' %' }
			];
		} else {
			if (!isFinite(p) || !isFinite(n)) { throw new Error('Completa el porcentaje y la parte conocida.'); }
			if (p === 0) { throw new Error('El porcentaje no puede ser cero.'); }
			x = (n * 100) / p;
			steps = [
				{ r: 'Plantea la regla de tres', t: fmt(p) + ' → ' + fmt(n) + '  y  100 → X' },
				{ r: 'Aplica la fórmula', t: 'X = (100 × ' + fmt(n) + ') ÷ ' + fmt(p) },
				{ r: 'Multiplica', t: '100 × ' + fmt(n) + ' = ' + fmt(n * 100) },
				{ r: 'Divide', t: fmt(n * 100) + ' ÷ ' + fmt(p) + ' = ' + fmt(x) }
			];
		}
		return { x: x, steps: steps, check: check };
	}

	/* ============================================================
	 * ICONS
	 * ========================================================== */

	var ICONS = {
		simple: '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="12" y1="4" x2="12" y2="20"/></svg>',
		compuesta: '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"/><line x1="3" y1="9.5" x2="21" y2="9.5"/><line x1="3" y1="15" x2="21" y2="15"/><line x1="13" y1="4" x2="13" y2="20"/></svg>',
		pct: '<svg viewBox="0 0 24 24"><line x1="19" y1="5" x2="5" y2="19"/><circle cx="7.5" cy="7.5" r="2.5"/><circle cx="16.5" cy="16.5" r="2.5"/></svg>',
		run: '<svg viewBox="0 0 24 24"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',
		check: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><polyline points="9 12 11 14 15 10"/></svg>',
		alert: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>',
		plus: '<svg viewBox="0 0 24 24"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
		eraser: '<svg viewBox="0 0 24 24"><path d="M20 20H8.5L3 14.5a2 2 0 0 1 0-2.8l8-8a2 2 0 0 1 2.8 0l6.7 6.7a2 2 0 0 1 0 2.8L14 19"/></svg>'
	};

	/* ============================================================
	 * OUTPUT RENDERING
	 * ========================================================== */

	function errorBox(msg) {
		return '<div class="art-err"><span class="art-ico">' + ICONS.alert + '</span>' + esc(msg) + '</div>';
	}

	function renderResult(r, unit) {
		var html = '<div class="art-result">' +
			'<div class="art-result-lab">Resultado</div>' +
			'<div class="art-result-val">X = ' + esc(fmt(r.x)) + (unit ? ' <span>' + esc(unit) + '</span>' : '') + '</div>' +
			'</div>';

		html += '<div class="art-sec">Procedimiento paso a paso</div><ol class="art-steps">';
		r.steps.forEach(function (s, i) {
			html += '<li class="art-step">' +
				'<div class="art-step-head"><span class="art-step-n">' + (i + 1) + '</span>' +
				'<span class="art-step-rule">' + esc(s.r) + '</span></div>' +
				'<div class="art-step-txt">' + esc(s.t) + '</div></li>';
		});
		html += '</ol>';

		if (r.check) {
			html += '<div class="art-ok"><span class="art-ico">' + ICONS.check + '</span>' +
				'<span><strong>Verificación: </strong>' + esc(r.check) + '</span></div>';
		}
		return html;
	}

	/* ============================================================
	 * MODE: SIMPLE
	 * ========================================================== */

	function buildSimple(root) {
		var shell = root.querySelector('[data-role="body"]');
		shell.innerHTML =
			'<div class="art-sec">Tipo de proporción</div>' +
			'<div class="art-types">' +
				'<button type="button" class="art-type active" data-type="directa">' +
					'<strong>Directa</strong><span>Más de una, más de la otra</span></button>' +
				'<button type="button" class="art-type" data-type="inversa">' +
					'<strong>Inversa</strong><span>Más de una, menos de la otra</span></button>' +
			'</div>' +
			'<div class="art-sec">Valores conocidos</div>' +
			'<div class="art-grid">' +
				'<label class="art-field"><span>Si A</span><input type="text" data-k="a" inputmode="decimal" placeholder="5"></label>' +
				'<label class="art-field"><span>equivale a B</span><input type="text" data-k="b" inputmode="decimal" placeholder="8"></label>' +
				'<label class="art-field"><span>entonces C</span><input type="text" data-k="c" inputmode="decimal" placeholder="12"></label>' +
				'<label class="art-field x"><span>equivale a X</span><div class="art-xbox" data-role="xbox">?</div></label>' +
			'</div>' +
			'<label class="art-field wide"><span>Unidad del resultado (opcional)</span>' +
				'<input type="text" data-k="unit" placeholder="euros, días, km..."></label>' +
			'<div class="art-actions">' +
				'<button type="button" class="art-run" data-role="run"><span class="art-ico">' + ICONS.run + '</span>Calcular</button>' +
				'<button type="button" class="art-clear" data-role="clear"><span class="art-ico">' + ICONS.eraser + '</span>Limpiar</button>' +
			'</div>' +
			'<div class="art-quick"><span>Ejemplos:</span>' +
				'<button type="button" data-ex="5|8|12|directa|euros">5 kg cuestan 8 € → 12 kg</button>' +
				'<button type="button" data-ex="6|30|10|inversa|días">6 obreros, 30 días → 10 obreros</button>' +
				'<button type="button" data-ex="60|4|80|inversa|horas">60 km/h, 4 h → 80 km/h</button>' +
			'</div>' +
			'<div data-role="out"></div>';

		var out = shell.querySelector('[data-role="out"]');
		var xbox = shell.querySelector('[data-role="xbox"]');
		var type = 'directa';
		function val(k) { return shell.querySelector('[data-k="' + k + '"]').value; }
		function setVal(k, v) { shell.querySelector('[data-k="' + k + '"]').value = v; }

		function run() {
			out.innerHTML = '';
			try {
				var r = solveSimple(parseNum(val('a')), parseNum(val('b')), parseNum(val('c')), type);
				xbox.textContent = fmt(r.x);
				xbox.classList.add('filled');
				out.innerHTML = renderResult(r, val('unit').trim());
			} catch (e) {
				xbox.textContent = '?';
				xbox.classList.remove('filled');
				out.innerHTML = errorBox(e.message);
			}
		}

		shell.addEventListener('click', function (ev) {
			var t = ev.target.closest('[data-type]');
			if (t) {
				type = t.getAttribute('data-type');
				shell.querySelectorAll('.art-type').forEach(function (b) { b.classList.toggle('active', b === t); });
				if (val('a') && val('b') && val('c')) { run(); }
				return;
			}
			if (ev.target.closest('[data-role="run"]')) { run(); return; }
			if (ev.target.closest('[data-role="clear"]')) {
				['a', 'b', 'c', 'unit'].forEach(function (k) { setVal(k, ''); });
				xbox.textContent = '?'; xbox.classList.remove('filled');
				out.innerHTML = '';
				return;
			}
			var ex = ev.target.closest('[data-ex]');
			if (ex) {
				var p = ex.getAttribute('data-ex').split('|');
				setVal('a', p[0]); setVal('b', p[1]); setVal('c', p[2]); setVal('unit', p[4] || '');
				type = p[3];
				shell.querySelectorAll('.art-type').forEach(function (b) {
					b.classList.toggle('active', b.getAttribute('data-type') === type);
				});
				run();
			}
		});
		shell.addEventListener('keydown', function (ev) {
			if (ev.key === 'Enter' && ev.target.tagName === 'INPUT') { ev.preventDefault(); run(); }
		});
	}

	/* ============================================================
	 * MODE: COMPUESTA
	 * ========================================================== */

	function magRow(i) {
		return '<div class="art-mag" data-row="' + i + '">' +
			'<input type="text" class="art-mag-name" data-m="name" placeholder="Magnitud ' + (i + 1) + ' (obreros, horas...)">' +
			'<div class="art-mag-vals">' +
				'<input type="text" data-m="from" inputmode="decimal" placeholder="De">' +
				'<span class="art-arrow">→</span>' +
				'<input type="text" data-m="to" inputmode="decimal" placeholder="A">' +
				'<select data-m="rel"><option value="inversa">Inversa</option><option value="directa">Directa</option></select>' +
			'</div></div>';
	}

	function buildCompuesta(root) {
		var shell = root.querySelector('[data-role="body"]');
		shell.innerHTML =
			'<div class="art-note">Usa este modo cuando intervienen tres o más magnitudes. Indica el valor conocido de lo que quieres calcular y, para cada magnitud, cómo cambia y si su relación es directa o inversa.</div>' +
			'<div class="art-sec">Valor conocido de la magnitud buscada</div>' +
			'<div class="art-grid two">' +
				'<label class="art-field"><span>Valor conocido</span><input type="text" data-k="base" inputmode="decimal" placeholder="10"></label>' +
				'<label class="art-field"><span>Unidad (opcional)</span><input type="text" data-k="unit" placeholder="días"></label>' +
			'</div>' +
			'<div class="art-sec">Magnitudes que cambian</div>' +
			'<div data-role="mags">' + magRow(0) + magRow(1) + '</div>' +
			'<button type="button" class="art-clear add" data-role="add"><span class="art-ico">' + ICONS.plus + '</span>Añadir magnitud</button>' +
			'<div class="art-actions">' +
				'<button type="button" class="art-run" data-role="run"><span class="art-ico">' + ICONS.run + '</span>Calcular</button>' +
				'<button type="button" class="art-clear" data-role="clear"><span class="art-ico">' + ICONS.eraser + '</span>Limpiar</button>' +
			'</div>' +
			'<div class="art-quick"><span>Ejemplo:</span>' +
				'<button type="button" data-exc="1">4 obreros, 6 h/día, 10 días → 5 obreros, 8 h/día</button>' +
			'</div>' +
			'<div data-role="out"></div>';

		var mags = shell.querySelector('[data-role="mags"]');
		var out = shell.querySelector('[data-role="out"]');

		function readRows() {
			return Array.prototype.map.call(mags.querySelectorAll('.art-mag'), function (row) {
				return {
					name: row.querySelector('[data-m="name"]').value.trim(),
					from: parseNum(row.querySelector('[data-m="from"]').value),
					to: parseNum(row.querySelector('[data-m="to"]').value),
					rel: row.querySelector('[data-m="rel"]').value
				};
			});
		}

		function run() {
			out.innerHTML = '';
			try {
				var r = solveCompuesta(parseNum(shell.querySelector('[data-k="base"]').value), readRows());
				out.innerHTML = renderResult(r, shell.querySelector('[data-k="unit"]').value.trim());
			} catch (e) {
				out.innerHTML = errorBox(e.message);
			}
		}

		shell.addEventListener('click', function (ev) {
			if (ev.target.closest('[data-role="add"]')) {
				var n = mags.querySelectorAll('.art-mag').length;
				if (n >= 4) { return; }
				mags.insertAdjacentHTML('beforeend', magRow(n));
				return;
			}
			if (ev.target.closest('[data-role="run"]')) { run(); return; }
			if (ev.target.closest('[data-role="clear"]')) {
				shell.querySelectorAll('input').forEach(function (i) { i.value = ''; });
				out.innerHTML = '';
				return;
			}
			if (ev.target.closest('[data-exc]')) {
				shell.querySelector('[data-k="base"]').value = '10';
				shell.querySelector('[data-k="unit"]').value = 'días';
				var rows = mags.querySelectorAll('.art-mag');
				var data = [['obreros', '4', '5', 'inversa'], ['horas al día', '6', '8', 'inversa']];
				data.forEach(function (d, i) {
					if (!rows[i]) { return; }
					rows[i].querySelector('[data-m="name"]').value = d[0];
					rows[i].querySelector('[data-m="from"]').value = d[1];
					rows[i].querySelector('[data-m="to"]').value = d[2];
					rows[i].querySelector('[data-m="rel"]').value = d[3];
				});
				run();
			}
		});
		shell.addEventListener('keydown', function (ev) {
			if (ev.key === 'Enter' && ev.target.tagName === 'INPUT') { ev.preventDefault(); run(); }
		});
	}

	/* ============================================================
	 * MODE: PORCENTAJES
	 * ========================================================== */

	var PCT = {
		deN: { l1: 'Porcentaje (%)', l2: 'Total', q: '¿Cuánto es el X % de un número?' },
		queP: { l1: 'Parte', l2: 'Total', q: '¿Qué porcentaje representa una parte del total?' },
		total: { l1: 'Porcentaje (%)', l2: 'Parte conocida', q: 'Si el X % es una cantidad, ¿cuál es el total?' }
	};

	function buildPorcentajes(root) {
		var shell = root.querySelector('[data-role="body"]');
		shell.innerHTML =
			'<div class="art-note">Todo cálculo de porcentaje es una regla de tres directa en la que el total equivale al 100 %.</div>' +
			'<div class="art-sec">¿Qué quieres calcular?</div>' +
			'<div class="art-types three">' +
				'<button type="button" class="art-type active" data-p="deN"><strong>% de un número</strong><span>15 % de 3.500</span></button>' +
				'<button type="button" class="art-type" data-p="queP"><strong>Qué % representa</strong><span>84 de 700</span></button>' +
				'<button type="button" class="art-type" data-p="total"><strong>Hallar el total</strong><span>12 % es 84</span></button>' +
			'</div>' +
			'<div class="art-grid two">' +
				'<label class="art-field"><span data-role="l1">Porcentaje (%)</span><input type="text" data-k="p" inputmode="decimal" placeholder="15"></label>' +
				'<label class="art-field"><span data-role="l2">Total</span><input type="text" data-k="n" inputmode="decimal" placeholder="3500"></label>' +
			'</div>' +
			'<div class="art-actions">' +
				'<button type="button" class="art-run" data-role="run"><span class="art-ico">' + ICONS.run + '</span>Calcular</button>' +
				'<button type="button" class="art-clear" data-role="clear"><span class="art-ico">' + ICONS.eraser + '</span>Limpiar</button>' +
			'</div>' +
			'<div data-role="out"></div>';

		var out = shell.querySelector('[data-role="out"]');
		var mode = 'deN';

		function run() {
			out.innerHTML = '';
			try {
				var r = solvePorcentaje(mode, parseNum(shell.querySelector('[data-k="p"]').value), parseNum(shell.querySelector('[data-k="n"]').value));
				out.innerHTML = renderResult(r, mode === 'queP' ? '%' : '');
			} catch (e) {
				out.innerHTML = errorBox(e.message);
			}
		}

		shell.addEventListener('click', function (ev) {
			var t = ev.target.closest('[data-p]');
			if (t) {
				mode = t.getAttribute('data-p');
				shell.querySelectorAll('.art-type').forEach(function (b) { b.classList.toggle('active', b === t); });
				shell.querySelector('[data-role="l1"]').textContent = PCT[mode].l1;
				shell.querySelector('[data-role="l2"]').textContent = PCT[mode].l2;
				out.innerHTML = '';
				return;
			}
			if (ev.target.closest('[data-role="run"]')) { run(); return; }
			if (ev.target.closest('[data-role="clear"]')) {
				shell.querySelectorAll('input').forEach(function (i) { i.value = ''; });
				out.innerHTML = '';
			}
		});
		shell.addEventListener('keydown', function (ev) {
			if (ev.key === 'Enter' && ev.target.tagName === 'INPUT') { ev.preventDefault(); run(); }
		});
	}

	/* ============================================================
	 * BOOT
	 * ========================================================== */

	function boot(root) {
		if (root.getAttribute('data-ready')) { return; }
		root.setAttribute('data-ready', '1');

		root.querySelectorAll('.art-ico[data-i]').forEach(function (el) {
			var k = el.getAttribute('data-i');
			if (ICONS[k]) { el.innerHTML = ICONS[k]; }
		});

		var builders = { simple: buildSimple, compuesta: buildCompuesta, porcentajes: buildPorcentajes };

		function show(mode) {
			root.querySelectorAll('.art-tab').forEach(function (t) {
				var on = t.getAttribute('data-mode') === mode;
				t.classList.toggle('active', on);
				t.setAttribute('aria-selected', on ? 'true' : 'false');
			});
			(builders[mode] || buildSimple)(root);
		}

		root.querySelectorAll('.art-tab').forEach(function (tab) {
			tab.addEventListener('click', function () { show(tab.getAttribute('data-mode')); });
		});

		show('simple');
	}

	function init() { document.querySelectorAll('.art-root').forEach(boot); }

	if (typeof document !== 'undefined') {
		if (!window.__aliciaRTLoaded) {
			window.__aliciaRTLoaded = true;
			if (document.readyState === 'loading') {
				document.addEventListener('DOMContentLoaded', init);
			} else { init(); }
		}
	}

	if (typeof module !== 'undefined' && module.exports) {
		module.exports = { solveSimple: solveSimple, solveCompuesta: solveCompuesta, solvePorcentaje: solvePorcentaje, fmt: fmt, parseNum: parseNum };
	}
})();
